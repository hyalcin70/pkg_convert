// pkg_convert_gui - native Qt6 GUI (kein Python)
// Wandelt .deb/.rpm -> Arch PKGBUILD + makepkg, alles ueber QProcess.
#include <QApplication>
#include <QMainWindow>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFrame>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QProgressBar>

// Sprach-Tabellen (pro Sprache eine eigene Datei lang_XX.cpp)
QMap<QString, QString> lang_de();
QMap<QString, QString> lang_en();
QMap<QString, QString> lang_fr();
QMap<QString, QString> lang_es();
QMap<QString, QString> lang_tr();
QMap<QString, QString> lang_pt();
#include <QListWidget>
#include <QFileDialog>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QMimeData>
#include <QUrl>
#include <QProcess>
#include <QTemporaryDir>
#include <QStandardPaths>
#include <QDirIterator>
#include <QMessageBox>
#include <QInputDialog>
#include <QRegularExpression>
#include <QComboBox>
#include <QDir>
#include <QFile>
#include <QSettings>

#include <QCryptographicHash>
#include <algorithm>

class DropLine : public QLineEdit {
    Q_OBJECT
public:
    explicit DropLine(QWidget *p = nullptr, const QString &placeholder = {})
        : QLineEdit(p) {
        setAcceptDrops(true);
        setReadOnly(true);
        if (!placeholder.isEmpty()) setPlaceholderText(placeholder);
    }
signals:
    void fileDropped(const QString &path);
protected:
    void dragEnterEvent(QDragEnterEvent *e) override {
        if (e->mimeData()->hasUrls()) e->acceptProposedAction();
    }
    void dropEvent(QDropEvent *e) override {
        const auto urls = e->mimeData()->urls();
        if (!urls.isEmpty()) {
            const QString p = urls.first().toLocalFile();
            setText(p);
            emit fileDropped(p);
        }
    }
};

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *p = nullptr) : QMainWindow(p) {
        setWindowTitle(i18n("title") + " – " + i18n("buildFor"));
        resize(760, 580);
        m_dark = m_settings.value("theme", "light").toString() == "dark";
        applyTheme();
        buildUi();
        // Sprache aus Settings laden (Standard: Deutsch)
        m_lang = m_settings.value("lang", "de").toString();
        applyLang();
        // Startup-Check für benötigte Tools
        checkRequiredTools();
    }

private:
    void checkRequiredTools() {
        struct Tool { QString cmd; QString pkg; QString hint; };
        const QVector<Tool> tools = {
            {"ar", "binutils", "für .deb-Entpackung (ar)"},
            {"cpio", "cpio", "für RPM-Entpackung (cpio)"},
            {"rpm2cpio", "rpm-tools", "für RPM-Entpackung (rpm2cpio)"},
            {"pkgfile", "pkgfile", "für Dependency-Resolver (pkgfile DB: 'sudo pkgfile -u')"},
            {"bsdtar", "libarchive", "für .MTREE & Entpackung"},
            {"zstd", "zstd", "für .pkg.tar.zst Kompression"},
            {"readelf", "binutils", "für ELF-Dependency-Scan (NEEDED)"},
            {"file", "file", "für ELF-Erkennung"},
        };
        QStringList missing;
        for (const auto &t : tools) {
            QProcess chk;
            chk.start("bash", QStringList() << "-c" << QString("command -v %1").arg(t.cmd));
            chk.waitForFinished(2000);
            if (chk.exitCode() != 0) {
                missing << QString("%1 (%2) – %3").arg(t.cmd, t.pkg, t.hint);
            }
        }
        if (!missing.isEmpty()) {
            QString msg = i18n("missingToolsTitle") + "\n\n";
            for (const auto &m : missing) msg += "• " + m + "\n";
            msg += "\n" + i18n("missingToolsHint");
            QMessageBox box(this);
            box.setWindowTitle(i18n("missingToolsTitle"));
            box.setText(msg);
            box.setIcon(QMessageBox::Warning);
            auto *installBtn = box.addButton(i18n("installMissing"), QMessageBox::ActionRole);
            auto *skipBtn = box.addButton(i18n("skip"), QMessageBox::RejectRole);
            box.setDefaultButton(installBtn);
            box.exec();
            if (box.clickedButton() == installBtn) {
                QStringList pkgs;
                for (const auto &m : missing) {
                    QString pkg = m.section('(', 1, 1).section(')', 0, 0);
                    if (!pkg.isEmpty() && !pkgs.contains(pkg)) pkgs << pkg;
                }
                QString cmd = "pkexec bash -c 'pacman -Sy --needed --noconfirm " + pkgs.join(" ") + " && pkgfile -u'";
                QProcess::startDetached("bash", QStringList() << "-c" << cmd);
            }
        }
    }

    QString i18n(const QString &key) const {
        static const QMap<QString, QMap<QString, QString>> T = {
            {"de", lang_de()},
            {"en", lang_en()},
            {"fr", lang_fr()},
            {"es", lang_es()},
            {"tr", lang_tr()},
            {"pt", lang_pt()},
        };
        const QMap<QString, QString> &m = T.value(m_lang, T.value("de"));
        return m.value(key, T.value("de").value(key, key));
    }

    void applyTheme() {
        const QString dark = R"(
            QMainWindow { background: #1e1e2e; }
            QLabel#title { font-size: 22px; font-weight: 600; color: #cdd6f4; }
            QLabel#sub { font-size: 12px; color: #a6adc8; }
            QFrame#card { background: #313244; border-radius: 12px; padding: 16px; }
            QLineEdit, QTextEdit {
                background: #181825; border: 1px solid #45475a;
                border-radius: 8px; color: #cdd6f4; padding: 8px;
                font-family: 'JetBrains Mono', monospace; font-size: 13px;
            }
            QPushButton {
                background: #89b4fa; color: #11111b; border: none;
                border-radius: 8px; padding: 10px 18px;
                font-weight: 600; font-size: 14px;
            }
            QPushButton:hover { background: #74a0f0; }
            QPushButton:disabled { background: #45475a; color: #6c7086; }
            QPushButton#ghost { background: transparent; border: 1px solid #585b70; color: #cdd6f4; }
            QPushButton#ghost:hover { background: #45475a; }
            QLabel#h { font-size: 13px; font-weight: 600; color: #b4befe; }
            QLabel#ok { color: #a6e3a1; }
            QLabel#bad { color: #f38ba8; }
        )";
        const QString light = R"(
            QMainWindow { background: #f5f6fa; }
            QLabel#title { font-size: 22px; font-weight: 600; color: #2e2e3a; }
            QLabel#sub { font-size: 12px; color: #5a5a6e; }
            QFrame#card { background: #ffffff; border-radius: 12px; padding: 16px; border: 1px solid #e2e4ec; }
            QLineEdit, QTextEdit {
                background: #ffffff; border: 1px solid #c8ccd8;
                border-radius: 8px; color: #2e2e3a; padding: 8px;
                font-family: 'JetBrains Mono', monospace; font-size: 13px;
            }
            QPushButton {
                background: #3b82f6; color: #ffffff; border: none;
                border-radius: 8px; padding: 10px 18px;
                font-weight: 600; font-size: 14px;
            }
            QPushButton:hover { background: #2563eb; }
            QPushButton:disabled { background: #c8ccd8; color: #8a8a9a; }
            QPushButton#ghost { background: transparent; border: 1px solid #a8adbd; color: #2e2e3a; }
            QPushButton#ghost:hover { background: #eceef4; }
            QLabel#h { font-size: 13px; font-weight: 600; color: #5b5bd6; }
            QLabel#ok { color: #2e9e4f; }
            QLabel#bad { color: #d83a5a; }
        )";
        setStyleSheet(m_dark ? dark : light);
    }

private slots:
    void toggleTheme() {
        m_dark = !m_dark;
        m_settings.setValue("theme", m_dark ? "dark" : "light");
        applyTheme();
        if (themeBtn) themeBtn->setText(m_dark ? i18n("themeLight") : i18n("themeDark"));
    }
    void applyLang() {
        if (titleLbl)  titleLbl->setText(i18n("title"));
        if (subLbl)    subLbl->setText(i18n("subtitle"));
        if (drop)      drop->setPlaceholderText(i18n("dropHint"));
        if (browseBtn) browseBtn->setText(i18n("browse"));
        if (metaLbl)   metaLbl->setText(i18n("noFile"));
        if (dep_h)     dep_h->setText(i18n("deps"));
        if (btnBuild)  btnBuild->setText(i18n("build"));
        if (btnInstall) btnInstall->setText(i18n("install"));
        if (inst_h)    inst_h->setText(i18n("installed"));
        if (uninstallBtn) uninstallBtn->setText(i18n("uninstall"));
        if (themeBtn)  themeBtn->setText(m_dark ? i18n("themeLight") : i18n("themeDark"));
        if (langLbl)   langLbl->setText(i18n("langLabel"));
        if (langCombo) {
            const int i = langCombo->findData(m_lang);
            if (i >= 0) langCombo->setCurrentIndex(i);
        }
    }

private slots:
    void browse() {
        // Startordner = zuletzt gewaehlter Quell-Ordner (sonst Home)
        const QString start = m_settings.value("lastSrcDir",
            QStandardPaths::writableLocation(QStandardPaths::HomeLocation)).toString();
        const QString p = QFileDialog::getOpenFileName(
            this, i18n("choosePkg"), start,
            i18n("pkgsFilter"));
        if (!p.isEmpty()) { drop->setText(p); onFile(p); }
    }
    void installPkg() {
        if (m_lastPkg.isEmpty() || !QFile::exists(m_lastPkg)) {
            status->setText(i18n("errNoBuiltPkg"));
            return;
        }
        // Allgemeiner Rat-Hinweis als EIGENES POPUP-FENSTER, ganz am ANFANG
        // (noch vor der Bestaetigungsfrage) – so uebersieht man ihn nicht.
        QMessageBox::information(this, i18n("hintInstallTitle"),
            i18n("hintInstallBody"));
        // Sicherheitsabfrage: welches Paket wird installiert?
        if (QMessageBox::question(this, i18n("confirmInstallTitle"),
                i18n("confirmInstallBody") + m_lastName + "\n(" + m_lastPkg + ")",
                QMessageBox::Yes | QMessageBox::No) != QMessageBox::Yes) {
            status->setText(i18n("msgInstAborted"));
            return;
        }
        // pkexec zeigt einen grafischen Polkit-Dialog an. Das ist robuster
        // als "sudo -S": PAM-Konfigurationen mit Fingerabdruck/Askpass
        // fressen das Passwort sonst aus stdin.
        // Ein einziger Aufruf: erst das Paket, dann die Repo-Abhaengigkeiten
        // (--asdeps) – damit der Auth-Dialog nur einmal erscheint.
        QString cmd = QString("pacman -U --noconfirm '%1'").arg(m_lastPkg);
        if (!m_lastDeps.isEmpty())
            cmd += " && pacman -S --asdeps --needed --noconfirm " + m_lastDeps.join(" ");
        QProcess sudo;
        sudo.start("pkexec", QStringList() << "bash" << "-c" << cmd);
        sudo.waitForFinished(-1);
        const int instExit = sudo.exitCode();
        const QByteArray err = sudo.readAllStandardError();
        QString instMsg;
        if (instExit != 0)
            instMsg = QString("\n❌ pacman -U fehlgeschlagen (Exit %1):\n%2")
                          .arg(instExit).arg(QString::fromUtf8(err).trimmed().right(400));
        // Repo-Abhaengigkeiten automatisch nachinstallieren (pacman -S --asdeps),
        // damit das Paket lauffaehig ist. Ergebnis wird VERIFIZIERT und gemeldet.
        QString depsMsg;
        if (!m_lastDeps.isEmpty()) {
            // Verifizieren: sind alle Deps jetzt wirklich installiert?
            QStringList missing;
            for (const QString &d : m_lastDeps) {
                QProcess q; q.start("pacman", QStringList() << "-Q" << d);
                q.waitForFinished();
                if (q.exitCode() != 0) missing << d;
            }
            if (missing.isEmpty())
                depsMsg = QString("\n" + i18n("depsInstalled") + "%1").arg(m_lastDeps.join(", "));
            else
                depsMsg = QString("\n" + i18n("depsFailed") + "%1\nFehler: %2")
                              .arg(missing.join(", "),
                                   QString::fromUtf8(err).trimmed().right(300));
        } else {
            depsMsg = QString("\n" + i18n("noRepoDeps"));
        }
        // Ergebnis pruefen: pacman -Q <pkgname> (nach erfolgreichem pacman -U)
        QProcess chk; chk.start("pacman", QStringList() << "-Q" << m_lastName);
        chk.waitForFinished();
        if (instExit == 0 && chk.exitCode() == 0) {
            status->setText(i18n("msgInstalled") + m_lastName + depsMsg);
            addInstalled(m_lastName);  // zur persistenten Historie hinzufuegen
        }
        else if (instExit != 0)
            status->setText(i18n("msgInstallFail") + instMsg + depsMsg);
        else
            status->setText(i18n("msgInstallPartial") + m_lastName + " installiert?)" + depsMsg);
    }
    // Hilfsfunktion: Namen zur persistenten Installations-Historie hinzufuegen
    void addInstalled(const QString &name) {
        QStringList lst = m_settings.value("installed", QStringList()).toStringList();
        if (!lst.contains(name)) lst << name;
        m_settings.setValue("installed", lst);
        refreshInstList();
    }
    // Hilfsfunktion: Namen aus der Historie entfernen
    void forgetInstalled(const QString &name) {
        QStringList lst = m_settings.value("installed", QStringList()).toStringList();
        lst.removeAll(name);
        m_settings.setValue("installed", lst);
        refreshInstList();
    }
    // Liste der installierten Pakete aus Settings neu aufbauen
    void refreshInstList() {
        if (!instList) return;
        instList->clear();
        const QStringList lst = m_settings.value("installed", QStringList()).toStringList();
        for (const QString &n : lst)
            instList->addItem(n);
    }
    void removePkg(const QString &name) {
        if (name.isEmpty()) {
            status->setText(i18n("msgNoPkgToRemove"));
            return;
        }
        // Sicherheitsabfrage: welches Paket wird deinstalliert?
        if (QMessageBox::question(this, i18n("confirmUninstallTitle"),
                i18n("confirmUninstallBody") + name,
                QMessageBox::Yes | QMessageBox::No) != QMessageBox::Yes) {
            status->setText(i18n("msgRmAborted"));
            return;
        }
        // pkexec siehe installPkg(): grafischer Polkit-Dialog statt sudo -S.
        QProcess sudo;
        sudo.start("pkexec", QStringList() << "pacman" << "-R" << "--noconfirm" << name);
        sudo.waitForFinished(-1);
        const QByteArray err = sudo.readAllStandardError();
        // Erfolg: nach Deinstallation darf pacman -Q den Namen NICHT mehr finden
        QProcess chk; chk.start("pacman", QStringList() << "-Q" << name);
        chk.waitForFinished();
        if (chk.exitCode() != 0) {
            status->setText(i18n("msgUninstallDone") + name);
            forgetInstalled(name);  // aus Historie entfernen
        }
        else if (sudo.exitCode() != 0)
            status->setText(i18n("msgUninstallFail") + QString::fromUtf8(err).trimmed());
        else
            status->setText(i18n("msgUninstallPartial") + name + " noch installiert?)");
    }
    void onFile(const QString &path) {
        m_path = path;
        // Ordner der Quelldatei merken, damit "Durchsuchen" dort startet
        m_settings.setValue("lastSrcDir", QFileInfo(path).absolutePath());
        if (!(path.endsWith(".deb") || path.endsWith(".rpm"))) {
            status->setText(i18n("errNoDebRpm"));
            return;
        }
        // Gewaehlte Datei gross anzeigen, damit kein Zweifel besteht,
        // WELCHES Paket gerade geladen ist (z.B. circuslinux vs. circuslinux-data).
        fileLbl->setText(i18n("chosen") + QFileInfo(path).fileName());
        btnBuild->setEnabled(true);
        m_lastName.clear();   // bei neuer Datei: alte Install/Remove-Ziele vergessen
        m_lastPkg.clear();
        m_lastDeps.clear();
        m_lastAurDeps.clear();
        status->setText(i18n("fileLabel") + QFileInfo(path).fileName());

        // Vorab-Metadaten lesen
        QTemporaryDir tmp;
        if (!tmp.isValid()) return;
        const QString staging = tmp.filePath("staging");
        QDir().mkpath(staging);
        const bool isDeb = path.endsWith(".deb");
        QMap<QString, QString> meta = parseMeta(path, staging, isDeb);
        metaLbl->setText(QString("Name: %1   Version: %2   Arch: %3   Format: %4")
            .arg(sanitizeName(meta.value("Package", "?")),
                 sanitizeVer(meta.value("Version", "?")),
                 meta.value("Architecture", "?"),
                 isDeb ? "DEB" : "RPM"));
    }
    void runConvert(bool build) {
        if (m_path.isEmpty()) return;
        btnBuild->setEnabled(false);
        progress->setVisible(true);
        progress->setRange(0, 0);
        status->setText(i18n("working"));

        QMessageBox hint(this);
        hint.setWindowTitle(i18n("warnIntroTitle"));
        hint.setText(i18n("warnIntro"));
        hint.setInformativeText(i18n("warnContinue"));
        hint.setIcon(QMessageBox::Warning);
        auto *okBtn = hint.addButton(QMessageBox::Ok);
        auto *cancelBtn = hint.addButton(QMessageBox::Cancel);
        Q_UNUSED(okBtn);
        hint.exec();
        if (hint.clickedButton() == cancelBtn) {
            progress->setVisible(false);
            btnBuild->setEnabled(true);
            status->setText(i18n("msgBuildAborted"));
            return;
        }

        QTemporaryDir tmp;
        const QString staging = tmp.filePath("staging");
        QDir().mkpath(staging);
        const bool isDeb = m_path.endsWith(".deb");
        QMap<QString, QString> meta = parseMeta(m_path, staging, isDeb);
        const QString name = sanitizeName(meta.value("Package", "converted"));
        const QString ver = sanitizeVer(meta.value("Version", "1.0"));
        QString pkgrel = meta.value("Release", "1");
        if (!QRegularExpression("^\\d+$").match(pkgrel).hasMatch()) pkgrel = "1";

        const QString arch = mapArch(meta.value("Architecture", "x86_64"));
        const QString desc = meta.value("Summary", meta.value("Description", "konvertiertes Paket")).split('\n').first().left(200);

        // Ziel-Verzeichnis vom User waehlen (Startordner = zuletzt gewaehlt, sonst Downloads)
        const QString lastDir = m_settings.value("lastOutDir",
            QStandardPaths::writableLocation(QStandardPaths::DownloadLocation)).toString();
        QFileDialog dlg(this, i18n("targetDir") + name, lastDir);
        dlg.setFileMode(QFileDialog::Directory);
        dlg.setOption(QFileDialog::ShowDirsOnly, true);
        dlg.setOption(QFileDialog::DontUseNativeDialog, true);
        if (dlg.exec() != QDialog::Accepted) {
            progress->setVisible(false);
            btnBuild->setEnabled(true);
            status->setText(i18n("errNoTarget"));
            return;
        }
        const QString out = dlg.selectedFiles().value(0);
        if (out.isEmpty()) {
            progress->setVisible(false);
            btnBuild->setEnabled(true);
            status->setText(i18n("errNoTarget"));
            return;
        }
        // gewaehlten Ordner merken (QSettings -> naechstes Mal Startordner)
        m_settings.setValue("lastOutDir", out);

        // Abfrage: nur Paket oder mit Quellen? (vor Berechnung von buildOut)
        QMessageBox box(this);
        box.setWindowTitle(i18n("buildTitle") + name);
        box.setText(i18n("buildAsk"));
        QPushButton *onlyPkg = box.addButton(i18n("buildOnly"), QMessageBox::ActionRole);
        QPushButton *withSrc = box.addButton(i18n("buildSrc"), QMessageBox::ActionRole);
        box.setDefaultButton(onlyPkg);
        box.exec();
        const bool withSources = (box.clickedButton() == withSrc);

        // Bei "Paket + Quellen": eigenen Unterordner <name>-<ver> verwenden,
        // damit Artefakte nicht andere Pakete im Zielordner ueberlagern.
        const QString buildOut = withSources
            ? out + "/" + name + "-" + ver : out;
        QDir().mkpath(buildOut);
        const QString src = buildOut + "/src/staging";
        QDir().mkpath(src);
        copyDir(staging, src);

        // Arch-Pfad-Anpassung ohne hardcodierte Namen:
        // * Konvertiere nur echte ELF-Binaries aus /usr/games nach /usr/bin,
        //   weil /usr/games unter Arch haeufig NICHT in $PATH liegt.
        // * Nur-verschieben statt alles kopieren/verschieben; Daten/Desktops bleiben unberuehrt.
        {
            const QString gamesDirPath = src + "/usr/games";
            QDir gamesDir(gamesDirPath);
            if (gamesDir.exists()) {
                QDir().mkpath(src + "/usr/bin");
                const auto entries = gamesDir.entryInfoList(QDir::AllEntries | QDir::NoDotAndDotDot);
                for (const QFileInfo &fi : entries) {
                    if (!fi.isFile()) continue;
                    QFile f(fi.filePath());
                    if (!f.open(QIODevice::ReadOnly)) continue;
                    const QByteArray magic = f.read(4);
                    f.close();
                    if (!magic.startsWith("\x7f" "ELF")) continue;
                    const QString dest = src + "/usr/bin/" + fi.fileName();
                    QFile::remove(dest);
                    if (!QFile::rename(fi.filePath(), dest)) {
                        // Fallback: falls rename scheitert, zuruecksetzen; keine hardcodierten Namen.
                        QFile::copy(fi.filePath(), dest);
                    }
                }
                // nur entfernen, wenn der Ordner danach tatsaechlich leer ist
                if (gamesDir.entryList(QDir::AllEntries | QDir::NoDotAndDotDot).isEmpty())
                    QDir(src + "/usr").rmdir("games");
            }
        }

        // Warnung, wenn dieses Paket KEIN ausfuehrbares Programm enthaelt
        // (z.B. circuslinux-data). Dann ist es allein nicht startbar.
        QString warnNoBinary;
        {
            bool foundBin = false;
            QDirIterator it(src, QDirIterator::Subdirectories);
            while (it.hasNext()) {
                it.next();
                const QFileInfo fi = it.fileInfo();
                if (!fi.isFile()) continue;
                QFile f(it.filePath());
                if (!f.open(QIODevice::ReadOnly)) continue;
                const QByteArray magic = f.read(4);
                f.close();
                if (!magic.startsWith("\x7f" "ELF")) continue;
                foundBin = true;
                break;
            }
            if (!foundBin && build) {
                warnNoBinary = i18n("warnNoBinary");
            }
        }

        // PKGBUILD schreiben
        QStringList mapped, unknown, aurDeps;
        QSet<QString> seen;
        const QSet<QString> shipped = collectShippedLibs(src);
        // debtap-Methode: echte Binaries scannen (readelf NEEDED) und jede
        // Library via pkgfile zum ECHTEN Arch-Repo-Paketnamen aufloesen.
        // Keine geratene Namenstabelle mehr.
        depsFromBinaries(src, shipped, mapped, unknown, aurDeps, seen);
        // Zusaetzlich Metadaten-Depends/Requires auswerten (dlopen-Libs).
        depsFromRequires(meta, isDeb, shipped, mapped, unknown, aurDeps, seen);
        // Deps fuer spaetere Installation merken
        m_lastDeps = mapped;
        m_lastAurDeps = aurDeps;
        QString pb;
        pb += "# Generiert von Paket Converter (deb/rpm -> Arch)\n";
        pb += QString("# Quelle: %1 (%2)\n").arg(meta.value("Package", name), isDeb ? "deb" : "rpm");
        pb += QString("pkgname=%1\n").arg(name);
        pb += QString("pkgver=%1\n").arg(ver);
        pb += QString("pkgrel=%1\n").arg(pkgrel);
        pb += QString("pkgdesc=\"%1\"\n").arg(desc);
        pb += QString("arch=('%1')\n").arg(arch);
        pb += QString("url=\"%1\"\n").arg(meta.value("URL", ""));
        pb += QString("license=('%1')\n").arg(meta.value("License", "custom"));
        pb += "depends=(\n";
        for (const auto &d : mapped) pb += "  '" + d + "'\n";
        if (mapped.isEmpty()) pb += "  # keine gemappt\n";
        pb += ")\n";
        pb += QString("# --- nicht gemappte Fremd-Abhaengigkeiten (manuell pruefen) ---\n");
        pb += QString("# TODO: %1\n").arg(unknown.isEmpty() ? "keine" : unknown.join(", "));
        if (!aurDeps.isEmpty()) {
            pb += QString("# --- ACHTUNG: nur im AUR verfuegbar (nicht automatisch installierbar) ---\n"
                         "# AUR: %1\n").arg(aurDeps.join(", "));
        }
        pb += "options=('!strip' '!emptydirs')\n";
        pb += "source=()\n";
        pb += "package() {\n";
        pb += "    cp -a \"$srcdir/staging/.\" \"$pkgdir/\"\n";
        pb += "}\n";

        QFile f(buildOut + "/PKGBUILD");
        if (!f.open(QIODevice::WriteOnly)) {
            status->setText(i18n("errPkgbuild") + out);
            progress->setVisible(false);
            btnBuild->setEnabled(true);
            return;
        }
        f.write(pb.toUtf8());
        f.close();

        QString result = QString("%1 (%2): %3\n").arg(i18n("mapped"), QString::number(mapped.size()),
            mapped.isEmpty() ? i18n("noMapped") : mapped.join(", "));
        result += QString("%1 (%2): %3\n\n").arg(i18n("unknown"), QString::number(unknown.size()),
            unknown.isEmpty() ? i18n("allOk") : unknown.join(", "));
        if (!warnNoBinary.isEmpty())
            result += warnNoBinary;
        if (!aurDeps.isEmpty())
            result += i18n("notSatisfiable") + aurDeps.join(", ")
                      + i18n("notSatisfiableNote");
        // --- Debian/RPM-Depends auswerten: welche ZUSATZPAKETE fehlen? ---
        // (Library-Deps werden bereits ueber readelf/pkgfile erkannt; hier geht
        //  es um reine Paket-Deps wie circuslinux-data, fonts-foo, -common ...)
        QStringList extraPkgs;
        {
            QString raw = meta.value(isDeb ? "Depends" : "Requires", "");
            // deb: komma-getrennt, kann Versionen haben ("pkg (>= 1.0) | alt")
            // rpm: eine Require pro Zeile
            QStringList items;
            if (isDeb) items = raw.split(',', Qt::SkipEmptyParts);
            else       items = raw.split('\n', Qt::SkipEmptyParts);
            const QRegularExpression verRe("\\s*[\\(|\\[].*"); // Version/Arch in Klammern weg
            const QStringList knownLibPrefix = {
                "libc", "libstdc", "libgcc", "libgl", "libglvnd", "libx", "libSDL",
                "libopenal", "libalut", "libncurses", "librecode", "glibc", "gcc-libs",
                "zlib", "libjpeg", "libpng", "freetype", "sdl", "libuuid", "libffi"
            };
            for (QString it : items) {
                it = it.split('|').first();          // Alternative (|) -> erste nehmen
                it = it.remove(verRe).trimmed();
                it = it.section(' ', 0, 0).trimmed(); // "pkg (>=..)" -> "pkg"
                if (it.isEmpty()) continue;
                // RPM-interne Pseudo-Deps (rpmlib, rtld(GNU_HASH), ...)
                // sind KEIN echtes Paket -> ignorieren
                if (it.startsWith("rpmlib") || it.startsWith("rtld(")
                    || it.startsWith("/") || (it.contains("(") && !it.contains(')'))) continue;
                // Library-artige Deps ueberspringen (die kommen ueber readelf)
                bool looksLib = false;
                for (const QString &p : knownLibPrefix)
                    if (it.startsWith(p) || it.contains(".so")) { looksLib = true; break; }
                if (looksLib) continue;
                // eigene Paketnamen (circuslinux-data) nicht doppelt listen
                if (it == name) continue;
                if (!extraPkgs.contains(it)) extraPkgs << it;
            }
        }
        if (!extraPkgs.isEmpty()) {
            result += i18n("extraDeps") + extraPkgs.join(", ")
                      + i18n("extraDepsNote");
        }

        result += i18n("pkgbuildLabel") + buildOut + "/PKGBUILD\n";

        // Paketmetadaten für pacman schreiben, damit das Ergebnis ein
        // vollwertiges .pkg.tar.zst wird. Erst jetzt, nach allen Bearbeitungen
        // an src/staging (games-Verschiebung etc.).
        writePackageMetadata(buildOut, name, ver, pkgrel, arch, desc, meta, isDeb, mapped);

        if (build) {
            // Paket wurde bereits von writePackageMetadata gebaut.
            const QString built = buildOut + "/" + QString("%1-%2-%3-%4.pkg.tar.zst").arg(name, ver, pkgrel, arch);
            if (QFile::exists(built)) {
                result += i18n("msgPkgBuilt") + "\n" + built + "\n";
                status->setText(i18n("msgPkgBuilt"));
                m_lastPkg = built;
                m_lastName = name;
                btnInstall->setEnabled(true);
            } else {
                result += i18n("msgBuildFail") + "\nPaketmetadaten konnten nicht geschrieben werden.\n";
                status->setText(i18n("msgBuildFail"));
            }
            // src-Paket Hinweis
            const QStringList srcs = QDir(buildOut).entryList(QStringList() << "*.src.tar.gz" << "*.src.tar.zst");
            if (!srcs.isEmpty())
                result += "✅ Sources: " + buildOut + "/" + srcs.first() + "\n";

            // Bei "Nur Paket": NUR die eigenen Arbeitsreste (pkg/, src/, PKGBUILD)
            // entfernen - niemals bereits vorhandene .pkg.tar.zst (fremde Pakete).
            if (!withSources) {
                QDir od(out);
                for (const QString &e : od.entryList(QDir::AllEntries | QDir::NoDotAndDotDot)) {
                    if (e == "pkg" || e == "src" || e == "PKGBUILD")
                        ; // diese entfernen
                    else
                        continue; // alles andere (inkl. fremder .pkg.tar.zst) behalten
                    QFileInfo fi(od.filePath(e));
                    if (fi.isDir()) QDir(od.filePath(e)).removeRecursively();
                    else od.remove(e);
                }
                result += i18n("cleanup");
            }
        } else {
            status->setText(i18n("msgPkgbuildDone"));
        }

        depView->setPlainText(result);
        progress->setVisible(false);
        btnBuild->setEnabled(true);
    }

private:
    // ---- helpers ----
    static QString mapDebDepToArch(const QString &dep) {
        static const QMap<QString, QString> debToArch = {
            {"libc6", "glibc"},
            {"libc6-base", "glibc"},
            {"libgcc1", "libgcc"},
            {"libgcc-s1", "libgcc"},
            {"libstdc++6", "libstdc++"},
            {"zlib1g", "zlib"},
            {"libssl1.1", "openssl-1.1"},
            {"libssl3", "openssl"},
            {"libcurl4", "curl"},
            {"libxml2", "libxml2"},
            {"libsqlite3-0", "sqlite"},
            {"libzstd1", "zstd"},
            {"liblzma5", "xz"},
            {"liblz4-1", "lz4"},
            {"libbz2-1.0", "bzip2"},
            {"libtiff5", "libtiff"},
            {"libpng16-16", "libpng"},
            {"libjpeg62-turbo", "libjpeg-turbo"},
            {"libfreetype6", "freetype2"},
            {"libfontconfig1", "fontconfig"},
            {"libexpat1", "expat"},
            {"libx11-6", "libx11"},
            {"libxext6", "libxext"},
            {"libxrender1", "libxrender"},
            {"libxi6", "libxi"},
            {"libxrandr2", "libxrandr"},
            {"libxcursor1", "libxcursor"},
            {"libxinerama1", "libxinerama"},
            {"libglib2.0-0", "glib2"},
            {"libgtk-3-0", "gtk3"},
            {"libqt5core5a", "qt5-base"},
            {"libqt5gui5", "qt5-base"},
            {"libqt5widgets5", "qt5-base"},
            {"libqt6core6", "qt6-base"},
            {"libqt6gui6", "qt6-base"},
            {"libqt6widgets6", "qt6-base"},
            {"libudev1", "systemd-libs"},
            {"libdbus-1-3", "dbus"},
            {"libasound2", "alsa-lib"},
            {"libpulse0", "libpulse"},
            {"libgl1", "libglvnd"},
            {"libegl1", "libglvnd"},
            {"libgles2", "libglvnd"},
            {"libvulkan1", "vulkan-icd-loader"},
            {"libxcb1", "libxcb"},
            {"libxkbcommon0", "xkbcommon"},
            {"libwayland-client0", "wayland"},
            {"libdrm2", "libdrm"},
            {"libgbm1", "mesa"},
            {"libnss3", "nss"},
            {"libnspr4", "nspr"},
            {"libcups2", "cups"},
            {"libxss1", "libxss"},
            {"libxtst6", "libxtst"},
            {"libxxf86vm1", "libxxf86vm"},
            {"libxcomposite1", "libxcomposite"},
            {"libxdamage1", "libxdamage"},
            {"libxfixes3", "libxfixes"},
            {"libxshmfence1", "libxshmfence"},
            {"libunwind8", "libunwind"},
            {"libblosc1", "c-blosc"},
            {"libhdf5-103", "hdf5"},
            {"libnetcdf19", "netcdf"},
            {"libjson-c5", "json-c"},
            {"libusb-1.0-0", "libusb"},
            {"libuuid1", "util-linux-libs"},
            {"libgpg-error0", "libgpg-error"},
            {"libassuan0", "assuan"},
            {"libgcrypt20", "libgcrypt"},
            {"libkrb5-3", "krb5"},
            {"libk5crypto3", "krb5"},
            {"libcom-err2", "krb5"},
            {"libkrb5support0", "krb5"},
            {"libselinux1", "libselinux"},
            {"libpcre2-8-0", "pcre2"},
            {"libpcre3", "pcre"},
            {"libreadline8", "readline"},
            {"libncurses6", "ncurses"},
            {"libtinfo6", "ncurses"},
            {"libgssapi-krb5-2", "krb5"},
            {"libldap-2.5-0", "ldb"},
            {"libsasl2-2", "cyrus-sasl"},
            {"libffi8", "libffi"},
            {"libyaml-0-2", "libyaml"},
        };
        QString cleaned = dep.trimmed();
        if (cleaned.isEmpty()) return dep;
        QString base = cleaned.split(QRegularExpression("[<>=~! ]"), Qt::SkipEmptyParts).value(0).trimmed();
        if (base.isEmpty()) return dep;
        const QString archName = debToArch.value(base);
        if (!archName.isEmpty()) {
            QString version = cleaned.mid(base.length()).trimmed();
            if (!version.isEmpty()) {
                return archName + version;
            }
            return archName;
        }
        return dep;
    }

    void writePackageMetadata(const QString &buildOut,
                              const QString &name,
                              const QString &ver,
                              const QString &pkgrel,
                              const QString &arch,
                              const QString &desc,
                              const QMap<QString, QString> &meta,
                              bool isDeb,
                              const QStringList &deps) {
        Q_UNUSED(isDeb);   // Deps kommen bereits als Arch-Namen herein
        const QString pkgroot = buildOut + "/pkg";
        QDir().mkpath(pkgroot);

        const QString src = buildOut + "/src/staging";
        if (QDir(src).exists()) {
            // Zuerst alle Dateien per Hardlink verschieben, wenn möglich —
            // das spart Speicher im fertigen Paket, weil große .so-Dateien
            // nicht doppelt vorkommen.
            const bool canHardlink = (src.startsWith(pkgroot) || pkgroot.startsWith(src));
            QDirIterator it(src, QDirIterator::Subdirectories);
            while (it.hasNext()) {
                it.next();
                const QFileInfo fi = it.fileInfo();
                if (fi.isDir()) continue;
                QString relPath = it.filePath().mid(src.length() + 1);
                if (relPath.startsWith("./")) relPath.remove(0, 2);
                if (relPath.isEmpty()) continue;
                const QString destPath = pkgroot + "/" + relPath;
                QDir().mkpath(QFileInfo(destPath).path());
                if (QFile::exists(destPath)) {
                    QFile::remove(destPath);
                }
                bool ok = false;
                if (canHardlink) {
                    ok = QFile::link(it.filePath(), destPath);
                }
                if (!ok) {
                    ok = QFile::copy(it.filePath(), destPath);
                }
                if (!ok) {
                    status->setText(i18n("linkCopyError") + destPath);
                    return;
                }
            }

            // Dann Duplikate erkennen: gleicher Basisname + gleiche Größe +
            // gleicher Inhalt -> nur einmal behalten, Rest als Hardlink/Symlink.
            QSet<QString> contentDupRemove;
            {
                QMap<QString, QList<QPair<QString, qint64>>> sizeMap;
                QDirIterator it2(pkgroot, QDirIterator::Subdirectories);
                while (it2.hasNext()) {
                    it2.next();
                    const QFileInfo fi = it2.fileInfo();
                    if (!fi.isFile()) continue;
                    const QString relPath = it2.filePath().mid(pkgroot.length() + 1);
                    if (!relPath.startsWith("usr/lib/")) continue;
                    if (!relPath.contains(".so")) continue;
                    const QString base = QFileInfo(relPath).completeBaseName();
                    if (base.isEmpty()) continue;
                    sizeMap[base].append({relPath, fi.size()});
                }

                for (const QString &base : sizeMap.keys()) {
                    const auto list = sizeMap.value(base);
                    if (list.size() <= 1) continue;
                    QList<QPair<QString, qint64>> sameSize;
                    qint64 refSize = -1;
                    for (const auto &p : list) {
                        if (refSize < 0) refSize = p.second;
                        if (p.second == refSize) sameSize.append(p);
                    }
                    if (sameSize.size() <= 1) continue;

                    // Inhaltsprüfung über Hash
                    QString keep;
                    QSet<QString> remove;
                    QSet<QString> seenHashes;
                    for (const auto &p : sameSize) {
                        QFile f(pkgroot + "/" + p.first);
                        if (!f.open(QIODevice::ReadOnly)) continue;
                        QCryptographicHash hash(QCryptographicHash::Md5);
                        hash.addData(&f);
                        f.close();
                        const QString h = QString::fromLatin1(hash.result().toHex());
                        if (seenHashes.contains(h)) {
                            remove.insert(p.first);
                        } else {
                            seenHashes.insert(h);
                            keep = p.first;
                        }
                    }
                    for (const QString &r : remove) {
                        if (r != keep) contentDupRemove.insert(r);
                    }
                }
            }

            for (const QString &relPath : contentDupRemove) {
                const QString full = pkgroot + "/" + relPath;
                if (QFile::exists(full)) {
                    QFile::remove(full);
                }
            }
        }

        // .PKGINFO
        const QString pkgver = QString("%1-%2").arg(ver, pkgrel);
        QString pkginfo = QString("# Generated by pkg_convert\n");
        pkginfo += QString("pkgname = %1\n").arg(name);
        pkginfo += QString("pkgver = %1\n").arg(pkgver);
        pkginfo += QString("pkgdesc = %1\n").arg(desc);
        pkginfo += QString("pkgbase = %1\n").arg(name);
        pkginfo += QString("url = %1\n").arg(meta.value("URL", ""));
        pkginfo += QString("builddate = %1\n").arg(QDateTime::currentSecsSinceEpoch());
        pkginfo += QString("packager = pkg_convert\n");
        pkginfo += QString("arch = %1\n").arg(arch);
        pkginfo += QString("license = %1\n").arg(meta.value("License", "custom"));
        // Nur die echten Arch-Abhaengigkeiten eintragen. Fremde Sonames /
        // Paketnamen (z.B. "libxkbcommon.so.0()(64bit)") kann pacman nicht
        // auflösen und würde die Installation scheitern lassen.
        for (const QString &d : deps) {
            const QString dep = d.trimmed();
            if (dep.isEmpty()) continue;
            pkginfo += QString("depend = %1\n").arg(dep);
        }

        QFile pkginfoFile(pkgroot + "/.PKGINFO");
        if (pkginfoFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
            pkginfoFile.write(pkginfo.toUtf8());
            pkginfoFile.close();
        }

        // .BUILDINFO
        QString buildinfo = QString("# Generated by pkg_convert\n");
        buildinfo += QString("builddate = %1\n").arg(QDateTime::currentSecsSinceEpoch());
        buildinfo += QString("startdir = %1\n").arg(buildOut);
        buildinfo += QString("pkgname = %1\n").arg(name);
        buildinfo += QString("pkgver = %1\n").arg(pkgver);
        buildinfo += "buildmachine = unknown\n";
        buildinfo += "packager = pkg_convert\n";

        QFile buildinfoFile(pkgroot + "/.BUILDINFO");
        if (buildinfoFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
            buildinfoFile.write(buildinfo.toUtf8());
            buildinfoFile.close();
        }

        // .MTREE — pacman erwartet plaintext, kein komprimiertes tar
        QProcess mtreeProcs;
        mtreeProcs.start("bsdtar", QStringList()
            << "-C" << pkgroot
            << "--format" << "mtree"
            << "--options=!all,use-set,type,uid,gid,mode,time,size,md5,sha256,link"
            << "." << ".PKGINFO" << ".BUILDINFO");
        mtreeProcs.waitForFinished(-1);
        QByteArray mtreeData = mtreeProcs.readAllStandardOutput();
        if (!mtreeData.isEmpty()) {
            QFile mtreeFile(pkgroot + "/.MTREE");
            if (mtreeFile.open(QIODevice::WriteOnly)) {
                mtreeFile.write(mtreeData);
                mtreeFile.close();
            }
        }

        // Build the final .pkg.tar.zst — debtap nutzt ultrakompression
        const QString finalPkg = buildOut + "/" + QString("%1-%2-%3-%4.pkg.tar.zst").arg(name, ver, pkgrel, arch);
        QProcess buildProc;
        buildProc.start("bash", QStringList() << "-c"
            << QString(R"(tar -c -C '%1' . --transform='s,^\./,,' | zstd -q -T0 --ultra -15 -c > '%2')").arg(pkgroot, finalPkg));
        buildProc.waitForFinished(-1);
    }

    QMap<QString, QString> parseMeta(const QString &path, const QString &staging, bool isDeb) {
        QMap<QString, QString> meta;
        if (isDeb) {
            QTemporaryDir work;
            QString ctrlDir = work.filePath("ctrl");
            QDir().mkpath(ctrlDir);
            // ar entpackt nach work (via bash cd, -C wird nicht von jedem ar unterstuetzt)
            QProcess arx; arx.start("bash", QStringList() << "-c"
                << QString("cd '%1' && ar x '%2'").arg(work.path(), path));
            arx.waitForFinished();
            if (arx.exitCode() != 0) {
                meta["_deb_ar_error"] = "ar x failed for deb archive";
                return meta;
            }
            // control
            QProcess ar; ar.start("bash", QStringList() << "-c"
                << QString("cd '%1' && ls control.tar* 2>/dev/null | head -1").arg(work.path()));
            ar.waitForFinished();
            QString ca = work.filePath(ar.readAllStandardOutput().trimmed());
            if (QFile::exists(ca)) {
                QProcess tar;
                tar.start("tar", QStringList() << "-xf" << ca << "-C" << ctrlDir);
                tar.waitForFinished();
                if (tar.exitCode() == 0) {
                    QFile cf(ctrlDir + "/control");
                    if (cf.open(QIODevice::ReadOnly)) {
                        const QString txt = cf.readAll();
                        for (const QString &line : txt.split('\n')) {
                            int idx = line.indexOf(':');
                            if (idx > 0) meta[line.left(idx).trimmed()] = line.mid(idx + 1).trimmed();
                        }
                    }
                }
            }
            // data
            QProcess ar2; ar2.start("bash", QStringList() << "-c"
                << QString("cd '%1' && ls data.tar* 2>/dev/null | head -1").arg(work.path()));
            ar2.waitForFinished(-1);
            QString da = work.filePath(ar2.readAllStandardOutput().trimmed());
            if (QFile::exists(da)) {
                QProcess tar2;
                tar2.start("tar", QStringList() << "-xf" << da << "-C" << staging);
                tar2.waitForFinished(-1);
                if (tar2.exitCode() != 0) {
                    meta["_deb_data_extract_error"] = QString("tar xf data.tar failed with exit code %1").arg(tar2.exitCode());
                    meta["_deb_data_stderr"] = tar2.readAllStandardError();
                }
            } else {
                meta["_deb_data_missing"] = "no data.tar in deb";
            }
        } else {
            // RPM: zuverlaessig via rpm2cpio | cpio entpacken (bsdtar kann
            // nicht alle RPM-Formate/Compressions lesen -> sonst leeres Paket)
            QProcess rp;
            rp.start("bash", QStringList() << "-c"
                << QString("rpm2cpio '%1' | (cd '%2' && cpio -idm 2>/dev/null)").arg(path, staging));
            rp.waitForFinished(-1);
            QProcess rpm;
            rpm.start("rpm", QStringList() << "-qp" << "--qf"
                << "%{NAME}\n%{VERSION}\n%{RELEASE}\n%{ARCH}\n%{SUMMARY}\n%{URL}\n%{LICENSE}\n"
                << path);
            rpm.waitForFinished();
            QStringList parts = QString(rpm.readAllStandardOutput()).split('\n');
            QStringList keys = {"Package", "Version", "Release", "Architecture", "Summary", "URL", "License"};
            for (int i = 0; i < keys.size() && i < parts.size(); ++i)
                meta[keys[i]] = parts[i].trimmed();
            QProcess req;
            req.start("rpm", QStringList() << "-qp" << "--requires" << path);
            req.waitForFinished();
            meta["Requires"] = req.readAllStandardOutput();
        }
        return meta;
    }
    QString sanitizeName(const QString &n) {
        QString s = n.toLower();
        s.replace(QRegularExpression("[^a-z0-9@._+-]"), "-");
        while (s.contains("--")) s.replace("--", "-");
        return s.replace(QRegularExpression("^-|-$"), "");
    }
    QString sanitizeVer(const QString &v) {
        QString s = v.trimmed();
        int c = s.indexOf(':'); if (c >= 0) s = s.mid(c + 1);
        s.replace(QRegularExpression("[-~^]"), "_");
        return s;
    }
    QString mapArch(const QString &a) {
        static const QMap<QString, QString> m = {
            {"amd64", "x86_64"}, {"x86_64", "x86_64"}, {"x86-64", "x86_64"},
            {"aarch64", "aarch64"}, {"arm64", "aarch64"},
            {"armhf", "armv7h"}, {"armv7hl", "armv7h"}, {"armel", "armv6h"},
            {"i386", "i686"}, {"i486", "i686"}, {"i586", "i686"},
            {"noarch", "any"}, {"all", "any"}, {"any", "any"}};
        return m.value(a, a);
    }
    // Normalisiert einen Namen fuer den Abgleich: .so-Suffix und fuehrendes
    // "lib" entfernen, Kleinbuchstaben, nur alphanumerische Zeichen.
    static QString normDepName(QString s) {
        const int i = s.indexOf(".so");
        if (i >= 0) s = s.left(i);
        if (s.startsWith("lib") && s.length() > 4) s = s.mid(3);
        s = s.toLower();
        s.remove(QRegularExpression("[^a-z0-9]"));
        return s;
    }

    // Bewertet, wie gut ein Paketname zu einer Library-Soname passt.
    // Exakte Uebereinstimmung zaehlt am meisten, Teilstrings weniger.
    // Dadurch gewinnt z.B. vulkan-icd-loader gegen brave-bin.
    // Zerlegt einen Namen in Token (fuer Familien-Abgleich wie
    // qt6-core -> qt6-base, sdl2-2.0 -> sdl2).
    static QStringList depTokens(QString s) {
        const int i = s.indexOf(".so");
        if (i >= 0) s = s.left(i);
        if (s.startsWith("lib") && s.length() > 4) s = s.mid(3);
        s.replace(QRegularExpression("([a-z0-9])([A-Z])"), "\\1 \\2");
        s = s.toLower();
        return s.split(QRegularExpression("[^a-z0-9]+"), Qt::SkipEmptyParts);
    }

    static int depNameScore(const QString &pkg, const QString &lib) {
        const QString p = normDepName(pkg), l = normDepName(lib);
        if (p.isEmpty() || l.isEmpty()) return 0;
        int sc = 0;
        if (p == l) sc += 1000;
        else if (p.contains(l)) sc += 500;
        else if (l.contains(p)) sc += 300;
        const QStringList pt = depTokens(pkg), lt = depTokens(lib);
        int overlap = 0;
        for (const QString &t : lt)
            if (pt.contains(t)) ++overlap;
        sc += overlap * 100;
        return sc;
    }

    // Mitgelieferte .so-Dateien (Basename) ermitteln, damit sie nicht als
    // externe Abhaengigkeit gelten.
    static QSet<QString> collectShippedLibs(const QString &dir) {
        QSet<QString> shipped;
        QProcess own;
        own.start("bash", QStringList() << "-c" << QString(
            "cd '%1' && find . -type f -name '*.so*' -printf '%f\\n' | sort -u").arg(dir));
        own.waitForFinished(15000);
        for (const QString &s : QString::fromUtf8(own.readAllStandardOutput()).split('\n', Qt::SkipEmptyParts))
            shipped.insert(s);
        return shipped;
    }

    // Eine Library-Soname ueber pkgfile zum Arch-Repo-Paket aufloesen.
    // Zwischen mehreren Kandidaten gewinnt der namensbeste Treffer; bei
    // Gleichstand zaehlt die Repo-Prioritaet (core/extra vor multilib
    // vor Rest). lib32-Pakete sind fuer 64-bit-Binaries falsch.
    void resolveLibrary(const QString &lib, const QSet<QString> &shipped,
                        QStringList &mapped, QStringList &aurDeps, QSet<QString> &seen) {
        if (lib.isEmpty() || shipped.contains(lib)) return;
        QProcess pf;
        pf.start("pkgfile", QStringList() << lib);
        pf.waitForFinished(20000);
        const QStringList hits = QString::fromUtf8(pf.readAllStandardOutput())
                                     .split('\n', Qt::SkipEmptyParts);
        if (hits.isEmpty()) {
            // Kein Repo-Paket enthaelt die EXAKTE Soname-Version
            // (z.B. librecode.so.0 vs. Arch librecode.so.3).
            // Ein Paket mit anderer Version wuerde das Binary NICHT
            // reparieren -> ehrlich als nicht erfuellbar melden.
            if (!aurDeps.contains(lib)) aurDeps << lib;
            return;
        }
        QString best;
        int bestScore = -1;
        int bestRepo = 99;
        for (const QString &h : hits) {
            const QString repo = h.section('/', 0, 0);
            const QString cand = h.section('/', 1, 1).section('\t', 0, 0).trimmed();
            if (cand.startsWith("lib32-")) continue;
            const int sc = depNameScore(cand, lib);
            const int rp = (repo == "core") ? 0 : (repo == "extra") ? 1
                         : (repo == "multilib") ? 2 : 3;
            if (sc > bestScore || (sc == bestScore && rp < bestRepo)) {
                best = cand; bestScore = sc; bestRepo = rp;
            }
        }
        if (best.isEmpty()) {
            // kein Repo-Paket liefert diese Library -> nur via AUR/manuell
            if (!aurDeps.contains(lib)) aurDeps << lib;
            return;
        }
        // Basispakete nicht als depends auffuehren
        if (best == "glibc" || best == "gcc-libs") return;
        if (!seen.contains(best)) { mapped << best; seen.insert(best); }
    }

    // debtap-Methode: alle ELF-Binaries im Staging scannen, benoetigte
    // Libraries (readelf NEEDED) sammeln und via pkgfile zum echten
    // Arch-Repo-Paket aufloesen. core/extra/multilib bevorzugt (kein AUR).
    void depsFromBinaries(const QString &stagingDir, const QSet<QString> &shipped,
                          QStringList &mapped, QStringList &unknown, QStringList &aurDeps,
                          QSet<QString> &seen) {
        // 1) Alle NEEDED-Libraries aller ELF-Dateien einsammeln
        // (sed statt grep -oP: keine Backslash-Escape-Fallen in C++-Strings)
        QProcess scan;
        scan.start("bash", QStringList() << "-c" << QString(
            "cd '%1' && find . -type f -print0 | xargs -0 file -N 2>/dev/null "
            "| grep 'ELF' | cut -d: -f1 "
            "| xargs -r -I{} readelf -d {} 2>/dev/null "
            "| grep NEEDED | sed 's/.*\\[//; s/\\].*//' | sort -u").arg(stagingDir));
        scan.waitForFinished(60000);
        const QStringList libs = QString::fromUtf8(scan.readAllStandardOutput())
                                     .split('\n', Qt::SkipEmptyParts);
        // Eigene mitgelieferte Libs wurden bereits vom Aufrufer ermittelt.
        for (const QString &lib : libs) {
            resolveLibrary(lib, shipped, mapped, aurDeps, seen);
        }
        Q_UNUSED(unknown);
    }
    void mapDeps(const QMap<QString, QString> &meta, bool isDeb, QStringList &mapped, QStringList &unknown, QStringList &aurDeps) {
        const QMap<QString, QString> common = {
            {"glibc", "glibc"}, {"libc6", "glibc"}, {"libstdc++6", "libstdc++"},
            {"libstdc++", "libstdc++"}, {"zlib1g", "zlib"}, {"zlib", "zlib"},
            {"gcc-libs", "gcc-libs"}, {"libgcc-s1", "gcc-libs"},
            {"libssl3", "openssl"}, {"openssl-libs", "openssl"},
            {"ca-certificates", "ca-certificates"}};
        const QMap<QString, QString> deb = {
            {"libglib2.0-0", "glib2"}, {"libgtk-3-0", "gtk3"}, {"libgtk2.0-0", "gtk2"},
            {"libpango-1.0-0", "pango"}, {"libcairo2", "cairo"},
            {"libgdk-pixbuf2.0-0", "gdk-pixbuf2"}, {"libx11-6", "libx11"},
            {"libxext6", "libxext"}, {"libxtst6", "libxtst"}, {"libusb-1.0-0", "libusb"},
            {"libudev1", "systemd-libs"}, {"libsystemd0", "systemd-libs"},
            {"libdbus-1-3", "dbus"}, {"libexpat1", "expat"}, {"libffi8", "libffi"},
            {"libpcre3", "pcre"}, {"fontconfig", "fontconfig"}, {"libfreetype6", "freetype2"},
            {"libpng16-16", "libpng"}, {"libjpeg62-turbo", "libjpeg-turbo"},
            {"librecode0", "recode"}, {"librecode3", "recode"},
            {"librecode16-3", "recode"}, {"librecode32-3", "recode"},
            {"libcurl4", "curl"}, {"libsqlite3-0", "sqlite"}, {"libxml2", "libxml2"},
            {"libncurses6", "ncurses"}, {"libreadline8", "readline"},
            {"libuuid1", "util-linux-libs"}, {"libpopt0", "popt"}, {"libgomp1", "gcc-libs"},
            {"libacl1", "acl"}, {"libattr1", "attr"},
            // Bibliotheks-Abhaengigkeiten (Debian SO-Paketnamen -> Arch)
            {"libglc0", "glc-lib"}, {"libalut0", "freealut"}, {"libopenal1", "openal"},
            {"libsdl2-2.0-0", "sdl2"}, {"libsdl2-image-2.0-0", "sdl2_image"},
            {"libsdl2-mixer-2.0-0", "sdl2_mixer"}, {"libsdl2-ttf-2.0-0", "sdl2_ttf"},
            {"libsdl1.2debian", "sdl"}, {"libgl1", "libgl"}, {"libglu1-mesa", "glu"},
            {"libglu1", "glu"}, {"libglvnd0", "libglvnd"}, {"libvorbis0a", "libvorbis"},
            {"libvorbisfile3", "libvorbis"}, {"libogg0", "libogg"}, {"libjpeg62-turbo", "libjpeg-turbo"},
            {"libpng16-16", "libpng"}, {"libxrandr2", "libxrandr"}, {"libxinerama1", "libxinerama"},
            {"libxxf86vm1", "libxxf86vm"}, {"libxcursor1", "libxcursor"}, {"libxi6", "libxi"},
            {"libxrender1", "libxrender"}, {"libxfixes3", "libxfixes"}, {"libxdamage1", "libxdamage"}};
        const QMap<QString, QString> rpm = {
            {"glib2", "glib2"}, {"glib2-0", "glib2"}, {"gtk3", "gtk3"}, {"gtk2", "gtk2"},
            {"pango", "pango"}, {"cairo", "cairo"}, {"libX11", "libx11"}, {"libXext", "libxext"},
            {"libXtst", "libxtst"}, {"libusb-1", "libusb"}, {"systemd-libs", "systemd-libs"},
            {"dbus-libs", "dbus"}, {"expat", "expat"}, {"libffi", "libffi"}, {"pcre", "pcre"},
            {"fontconfig", "fontconfig"}, {"freetype", "freetype2"}, {"libpng", "libpng"},
            {"libjpeg-turbo", "libjpeg-turbo"}, {"curl", "curl"}, {"sqlite", "sqlite"},
            {"libxml2", "libxml2"}, {"ncurses", "ncurses"}, {"readline", "readline"},
            {"util-linux", "util-linux-libs"}, {"popt", "popt"}, {"openssl", "openssl"},
            {"zlib", "zlib"}, {"acl", "acl"}, {"attr", "attr"},
            // Bibliotheks-Abhaengigkeiten (RPM SO-Namen inkl. .so.N -> Arch-Pakete)
            {"libGLC.so.0", "glc-lib"}, {"libalut.so.0", "freealut"}, {"libopenal.so.1", "openal"},
            {"libSDL2-2.0.so.0", "sdl2"}, {"libSDL2_image-2.0.so.0", "sdl2_image"},
            {"libSDL2_mixer-2.0.so.0", "sdl2_mixer"}, {"libSDL2_ttf-2.0.so.0", "sdl2_ttf"},
            {"libSDL-1.2.so.0", "sdl"}, {"libGL.so.1", "libgl"}, {"libGLU.so.1", "glu"},
            {"libGLX.so.0", "libglvnd"}, {"libEGL.so.1", "libglvnd"},
            {"libXrandr.so.2", "libxrandr"}, {"libXinerama.so.1", "libxinerama"},
            {"libXxf86vm.so.1", "libxxf86vm"}, {"libXcursor.so.1", "libxcursor"},
            {"libXi.so.6", "libxi"}, {"libXrender.so.1", "libxrender"},
            {"libXfixes.so.3", "libxfixes"}, {"libXdamage.so.1", "libxdamage"}, {"libXft.so.2", "libxft"},
            {"libvorbis.so.0", "libvorbis"}, {"libvorbisfile.so.3", "libvorbis"},
            {"libogg.so.0", "libogg"}, {"libpng16.so.16", "libpng"},
            {"libjpeg.so.62", "libjpeg-turbo"}, {"libz.so.1", "zlib"},
            // Debian-spezifische Pakete, die auf Arch nicht existieren -> ignorieren
            // (Daten sind bereits im umgewandelten Paket enthalten, oder es gibt
            // kein Arch-Aequivalent, das als depends sinnvoll waere)
            {"chromium-bsu-data", ""}, {"fonts-uralic", ""}, {"ttf-uralic", ""},
            {"libc6", ""}, {"libgcc1", ""}, {"libstdc++6", ""}, {"dpkg", ""},
            {"fonts-dejavu", ""}, {"ttf-dejavu", ""}};
        QStringList raw = isDeb
            ? meta.value("Depends", "").split(',', Qt::SkipEmptyParts)
            : meta.value("Requires", "").split('\n', Qt::SkipEmptyParts);
        QSet<QString> seen;
        for (QString part : raw) {
            part = part.trimmed();
            if (part.isEmpty()) continue;
            QString name;
            if (isDeb) name = part.split(QRegularExpression("[\\s(]")).first().trimmed();
            else {
                if (part.startsWith("rpmlib(") || part.startsWith("/"))
                    continue;
                name = part.split(QRegularExpression("[ <>=!\\[]")).first().trimmed();
                // GLIBC-interne Laufzeit-Libs nicht als Abhaengigkeit setzen
                // (libc, libm, libgcc_s, libstdc++, libdl, librt, libpthread ...)
                if (name == "libc" || name == "libm" || name == "libgcc_s" ||
                    name == "libstdc++" || name == "libdl" || name == "librt" ||
                    name == "libpthread" || name == "libresolv" || name == "libutil")
                    continue;
            }
            if (name.isEmpty() || name.contains('(')) continue;
            const QMap<QString, QString> &tbl = isDeb ? deb : rpm;
            QString m = tbl.value(name, common.value(name));
            // AUR-only Pakete (nicht in offiziellen Repos) duerfen NICHT in
            // depends=() landen, sonst scheitert pacman -S. Sie werden separat
            // als Warnung gemeldet (koennen ohne AUR nicht installiert werden).
            static const QSet<QString> aurOnly = {"glc-lib", "qt4", "libtxc_dxtn"};
            if (!m.isEmpty() && aurOnly.contains(m)) {
                if (!aurDeps.contains(m)) aurDeps << m;
                continue;
            }
            if (!m.isEmpty()) {
                // Nur in depends=() / Auto-Install aufnehmen, wenn das Paket
                // WIRKLICH in den konfigurierten Repos existiert. Sonst wuerde
                // 'pacman -S' still fehlschlagen und nichts installiert werden.
                QProcess ss;
                ss.start("bash", QStringList() << "-c"
                    << QString("pacman -Ss '^%1$' >/dev/null 2>&1").arg(m));
                ss.waitForFinished();
                const bool exists = (ss.exitCode() == 0);
                if (exists) {
                    if (!seen.contains(m)) { mapped << m; seen.insert(m); }
                } else {
                    if (!unknown.contains(m)) unknown << m;
                }
            } else { if (!unknown.contains(name)) unknown << name; }
        }
    }

    // Zusaetzlich zur readelf-Analyse: die Fremd-Depends/Requires aus den
    // Paketmetadaten auswerten. Gerade bei Programmen, die Bibliotheken erst
    // zur Laufzeit per dlopen laden (X11, Wayland, Vulkan, ...), stehen diese
    // NICHT im readelf-NEEDED des Hauptbinaries und wurden vorher ignoriert.
    void depsFromRequires(const QMap<QString, QString> &meta, bool isDeb,
                          const QSet<QString> &shipped,
                          QStringList &mapped, QStringList &unknown, QStringList &aurDeps,
                          QSet<QString> &seen) {
        const QString raw = meta.value(isDeb ? "Depends" : "Requires", "");
        if (raw.isEmpty()) return;
        const QStringList items = isDeb ? raw.split(',', Qt::SkipEmptyParts)
                                        : raw.split('\n', Qt::SkipEmptyParts);
        QStringList foreignNames;
        for (QString item : items) {
            item = item.trimmed();
            if (item.isEmpty()) continue;
            if (!isDeb && (item.startsWith("rpmlib") || item.startsWith("rtld(") || item.startsWith("/")))
                continue;
            // RPM-Arch-Tag "(...)(64bit)" entfernen
            item.remove(QRegularExpression("\\(\\)\\([^)]*\\)"));
            QString inner = item.trimmed();
            if (inner.startsWith('(') && inner.endsWith(')'))
                inner = inner.mid(1, inner.length() - 2).trimmed();
            // Alternativen "(a or b)" / "a | b" einzeln behandeln
            const QStringList alts = inner.split(QRegularExpression("\\s+or\\s+|\\|"), Qt::SkipEmptyParts);
            for (QString alt : alts) {
                alt = alt.trimmed();
                if (alt.isEmpty()) continue;
                // Versions-/Arch-Klammern weg: alles ab <>=![(
                const int cut = alt.indexOf(QRegularExpression("[<>=!\\[(]"));
                if (cut >= 0) alt = alt.left(cut).trimmed();
                alt = alt.section(' ', 0, 0).trimmed();
                if (isDeb && alt.contains(':')) alt = alt.section(':', 0, 0).trimmed(); // "pkg:anyhf"
                if (alt.isEmpty()) continue;
                if (alt.contains(".so")) {
                    resolveLibrary(alt, shipped, mapped, aurDeps, seen);
                } else if (!alt.startsWith("rpmlib")) {
                    foreignNames << alt;
                }
            }
        }
        if (foreignNames.isEmpty()) return;
        // Fremdpaketnamen ueber die bestehenden Mapping-Tabellen pruefen
        // (inkl. Pruefung, ob das Zielpaket wirklich in den Repos existiert).
        QMap<QString, QString> synth = meta;
        synth.insert(isDeb ? "Depends" : "Requires",
                     foreignNames.join(isDeb ? QString(", ") : QString("\n")));
        mapDeps(synth, isDeb, mapped, unknown, aurDeps);
        mapped.removeDuplicates();
        unknown.removeDuplicates();
    }
    void copyDir(const QString &src, const QString &dst) {
        QDir d(src);
        for (const QFileInfo &fi : d.entryInfoList(QDir::AllEntries | QDir::NoDotAndDotDot)) {
            const QString target = dst + "/" + fi.fileName();
            if (fi.isDir()) { QDir().mkpath(target); copyDir(fi.filePath(), target); }
            else QFile::copy(fi.filePath(), target);
        }
    }

    void buildUi() {
        auto *root = new QWidget(this);
        setCentralWidget(root);
        auto *v = new QVBoxLayout(root);
        v->setContentsMargins(24, 24, 24, 24);
        v->setSpacing(16);

        // Header mit Titel + Theme-Toggle + Sprachauswahl
        auto *header = new QHBoxLayout();
        titleLbl = new QLabel(i18n("title")); titleLbl->setObjectName("title");
        auto *sub = new QLabel(i18n("subtitle"));
        sub->setObjectName("sub");
        subLbl = sub;
        auto *leftHead = new QVBoxLayout();
        leftHead->addWidget(titleLbl); leftHead->addWidget(sub);
        header->addLayout(leftHead, 1);
        // Sprachauswahl
        auto *langRow = new QHBoxLayout();
        langLbl = new QLabel(i18n("langLabel")); langLbl->setObjectName("sub");
        langCombo = new QComboBox();
        langCombo->addItem("DE", "de");
        langCombo->addItem("EN", "en");
        langCombo->addItem("FR", "fr");
        langCombo->addItem("ES", "es");
        langCombo->addItem("TR", "tr");
        langCombo->addItem("PT", "pt");
        langCombo->setFixedWidth(90);
        connect(langCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [this](int i) {
            m_lang = langCombo->itemData(i).toString();
            m_settings.setValue("lang", m_lang);
            applyLang();
        });
        langRow->addWidget(langLbl);
        langRow->addWidget(langCombo);
        header->addLayout(langRow, 0);
        themeBtn = new QPushButton(i18n(m_dark ? "themeLight" : "themeDark"));
        themeBtn->setObjectName("ghost");
        themeBtn->setFixedWidth(110);
        connect(themeBtn, &QPushButton::clicked, this, &MainWindow::toggleTheme);
        header->addWidget(themeBtn, 0, Qt::AlignTop);
        header->addWidget(themeBtn, 0, Qt::AlignTop);
        v->addLayout(header);
        v->addSpacing(4);

        auto *card = new QFrame(); card->setObjectName("card");
        auto *cv = new QVBoxLayout(card); cv->setSpacing(12);
        auto *hl = new QHBoxLayout();
        drop = new DropLine(this);
        drop->setMinimumHeight(44);
        if (drop) drop->setPlaceholderText(i18n("dropHint"));
        browseBtn = new QPushButton(i18n("browse")); browseBtn->setObjectName("ghost");
        connect(browseBtn, &QPushButton::clicked, this, &MainWindow::browse);
        connect(drop, &DropLine::fileDropped, this, &MainWindow::onFile);
        hl->addWidget(drop, 3); hl->addWidget(browseBtn, 1);
        cv->addLayout(hl);
        metaLbl = new QLabel(i18n("noFile")); metaLbl->setObjectName("h");
        cv->addWidget(metaLbl);
        fileLbl = new QLabel(""); fileLbl->setObjectName("sub");
        cv->addWidget(fileLbl);
        v->addWidget(card);

        dep_h = new QLabel(i18n("deps")); dep_h->setObjectName("h");
        v->addWidget(dep_h);
        depView = new QTextEdit(); depView->setReadOnly(true); depView->setMinimumHeight(150);
        v->addWidget(depView);

        auto *bcard = new QFrame(); bcard->setObjectName("card");
        auto *bv = new QVBoxLayout(bcard);
        progress = new QProgressBar(); progress->setVisible(false);
        bv->addWidget(progress);
        auto *bl = new QHBoxLayout();
        btnBuild = new QPushButton(i18n("build")); btnBuild->setEnabled(false);
        connect(btnBuild, &QPushButton::clicked, this, [this] { runConvert(true); });
        btnInstall = new QPushButton(i18n("install")); btnInstall->setEnabled(false);
        connect(btnInstall, &QPushButton::clicked, this, &MainWindow::installPkg);
        bl->addWidget(btnBuild, 2);
        bl->addWidget(btnInstall, 1);
        bv->addLayout(bl);
        v->addWidget(bcard);

        // Liste der installierten Pakete (persistent ueber QSettings)
        auto *icard = new QFrame(); icard->setObjectName("card");
        auto *iv = new QVBoxLayout(icard);
        inst_h = new QLabel(i18n("installed")); inst_h->setObjectName("h");
        iv->addWidget(inst_h);
        instList = new QListWidget();
        instList->setMinimumHeight(90);
        iv->addWidget(instList);
        uninstallBtn = new QPushButton(i18n("uninstall")); uninstallBtn->setObjectName("ghost");
        connect(uninstallBtn, &QPushButton::clicked, this, [this] {
            QListWidgetItem *it = instList->currentItem();
            if (it) removePkg(it->text());
            else status->setText(i18n("msgChooseFirst"));
        });
        iv->addWidget(uninstallBtn);
        v->addWidget(icard);

        refreshInstList();  // Historie aus Settings laden
        v->addStretch(1);
        status = new QLabel(""); status->setObjectName("sub");
        // Text markier- und kopierbar machen (Maus + Tastatur)
        status->setTextInteractionFlags(Qt::TextSelectableByMouse | Qt::TextSelectableByKeyboard);
        status->setCursor(Qt::IBeamCursor);
        v->addWidget(status);

        // Branding: "created by SattNEK" (ganz unten, mittig)
        auto *brand = new QLabel();
        brand->setObjectName("brand");
        brand->setAlignment(Qt::AlignCenter);
        // Logo aus mehreren moeglichen Pfaden laden (Build-Ordner + installiert)
        QString brandPath;
        QStringList brandCandidates{
            QCoreApplication::applicationDirPath() + "/created_by_sattnek.png",
            "/usr/share/icons/hicolor/scalable/apps/created_by_sattnek.png",
            "/usr/share/pkg_convert/created_by_sattnek.png"
        };
        for (const QString &c : brandCandidates) {
            if (QFile::exists(c)) { brandPath = c; break; }
        }
        if (!brandPath.isEmpty()) {
            QPixmap bm(brandPath);
            // auf max 360px Breite skalieren
            if (bm.width() > 360) bm = bm.scaledToWidth(360, Qt::SmoothTransformation);
            brand->setPixmap(bm);
        } else {
            brand->setText(i18n("brandFallback"));
        }
        v->addWidget(brand);
    }

    DropLine *drop = nullptr;
    QLabel *metaLbl = nullptr, *status = nullptr, *fileLbl = nullptr, *langLbl = nullptr;
    QLabel *titleLbl = nullptr, *subLbl = nullptr, *dep_h = nullptr, *inst_h = nullptr;
    QTextEdit *depView = nullptr;
    QProgressBar *progress = nullptr;
    QPushButton *btnBuild = nullptr, *themeBtn = nullptr, *btnInstall = nullptr;
    QPushButton *browseBtn = nullptr, *uninstallBtn = nullptr;
    QComboBox *langCombo = nullptr;
    QListWidget *instList = nullptr;  // Liste der installierten Pakete (persistent)
    QString m_path;
    QString m_lastPkg;  // Pfad zum zuletzt gebauten Paket (fuer Installieren)
    QString m_lastName; // pkgname des zuletzt gebauten Pakets
    QStringList m_lastDeps;     // gemappte Repo-Abhaengigkeiten (fuer pacman -S --asdeps)
    QStringList m_lastAurDeps;  // Abhaengigkeiten, die nur im AUR liegen (nicht automatisch installierbar)
    bool m_dark = false;
    QString m_lang = "de";
    QSettings m_settings{ "pkg_convert", "gui" };
};

int main(int argc, char **argv) {
    QApplication a(argc, argv);
    a.setFont(QFont("Noto Sans", 11));
    MainWindow w;
    w.show();
    return a.exec();
}

#include "pkg_convert_gui.moc"
